# Chronicle Installation Guide

## 📦 **Quick Installation**

### **Step 1: Download Chronicle**
Download the `chronicle.kiro.hook` file from this repository.

### **Step 2: Locate Your Workspace**
Navigate to your Kiro workspace directory where you want to use Chronicle.

### **Step 3: Create .kiro Folder**
If it doesn't exist, create a `.kiro` folder in your workspace:
```bash
mkdir .kiro
```

### **Step 4: Install Hook**
Copy `chronicle.kiro.hook` into the `.kiro` folder:
```
Your-Workspace/
├── .kiro/
│   └── chronicle.kiro.hook    # Place the file here
└── [your project files...]
```

### **Step 5: Activate**
- Restart Kiro completely, or
- Refresh the hooks panel in Kiro
- Chronicle should now appear in your available hooks

## 🔧 **Verification**

### **Check Installation**
1. Open Kiro in your workspace
2. Look for "Chronicle" in the hooks panel
3. Description should show: "Multi-session project documentation system"
4. Version should be "2.0"

### **Test Run**
1. Do some work in your session (create files, have conversations)
2. Manually trigger the Chronicle hook
3. Check for generated files:
   - `chronicle-[project-name]-master.html`
   - `chronicle-[project-name]-session-1-[timestamp].md`

## 🎯 **Configuration Options**

### **Project Naming**
Chronicle automatically uses your workspace folder name as the project name. To customize:
- Rename your workspace folder, or
- The first session will establish the project name pattern

### **File Locations**
By default, Chronicle saves files to your current workspace. Files can be moved to a dedicated Chronicle folder:
```
/Users/[username]/Documents/Chronicle/
├── Project-A/
│   ├── chronicle-project-a-master.html
│   └── sessions/
└── Project-B/
    ├── chronicle-project-b-master.html
    └── sessions/
```

## 🔄 **Multi-Workspace Setup**

### **Global Installation**
To use Chronicle across multiple workspaces:

1. **Option A: Copy to Each Workspace**
   - Copy `chronicle.kiro.hook` to each workspace's `.kiro/` folder
   - Each workspace gets independent Chronicle functionality

2. **Option B: Symbolic Links** (Advanced)
   ```bash
   # Create a master Chronicle location
   mkdir ~/Chronicle-Hook
   cp chronicle.kiro.hook ~/Chronicle-Hook/
   
   # Link from each workspace
   ln -s ~/Chronicle-Hook/chronicle.kiro.hook /path/to/workspace/.kiro/
   ```

### **Project Organization**
For multi-project workflows:
```
Development/
├── Project-Alpha/
│   ├── .kiro/chronicle.kiro.hook
│   └── chronicle-project-alpha-master.html
├── Project-Beta/
│   ├── .kiro/chronicle.kiro.hook
│   └── chronicle-project-beta-master.html
└── Chronicle-Archive/
    ├── completed-projects/
    └── templates/
```

## 🛠 **Troubleshooting**

### **Hook Not Visible**
```bash
# Check file location
ls -la .kiro/
# Should show: chronicle.kiro.hook

# Check file permissions
chmod 644 .kiro/chronicle.kiro.hook

# Verify JSON syntax
cat .kiro/chronicle.kiro.hook | python -m json.tool
```

### **Permission Issues**
```bash
# Fix folder permissions
chmod 755 .kiro/

# Fix file permissions
chmod 644 .kiro/chronicle.kiro.hook
```

### **Kiro Not Detecting Hook**
1. **Complete Restart**: Quit Kiro entirely and reopen
2. **Clear Cache**: Check Kiro settings for cache clearing options
3. **Workspace Reload**: Close and reopen the workspace
4. **File Validation**: Ensure the hook file is valid JSON

### **Generated Files Issues**
- **Missing Files**: Check workspace write permissions
- **Corrupted Output**: Verify sufficient disk space
- **Styling Problems**: Test HTML files in different browsers

## 🔧 **Advanced Configuration**

### **Custom Colors**
Edit the hook file to modify theme colors:
```json
"design": { "bg": "#YOUR_COLOR20", "text": "#YOUR_COLOR", "border": "#YOUR_COLOR40" }
```

### **Custom Categories**
Modify filter categories in the hook prompt:
```
- Design: Your custom description
- System: Your custom description  
- Problem solving: Your custom description
```

### **Output Customization**
Adjust file naming patterns in the hook prompt:
```
chronicle-[YOUR-PREFIX]-master.html
chronicle-[YOUR-PREFIX]-session-[N]-[TIMESTAMP].md
```

## 📋 **Verification Checklist**

- [ ] `chronicle.kiro.hook` file in `.kiro/` folder
- [ ] File permissions set correctly (644)
- [ ] Kiro restarted after installation
- [ ] Chronicle appears in hooks panel
- [ ] Test run produces expected files
- [ ] HTML file opens and displays correctly
- [ ] Theme switching works properly
- [ ] Filter buttons function correctly

## 🎉 **You're Ready!**

Chronicle is now installed and ready to document your collaborative AI sessions. Start working on a project and trigger Chronicle when you're ready to capture your progress!

---

Need help? Check the main README.md for usage examples and troubleshooting tips.