# Chronicle 📚
**Multi-Session Project Documentation System for Kiro AI**

Chronicle is an intelligent agent hook that automatically captures, analyzes, and documents collaborative work sessions between users and AI assistants across multiple sessions. It creates comprehensive, cumulative reports that track the entire journey from problem identification to solution delivery.

## 🎯 **Key Features**

### **Multi-Session Support**
- **Cumulative Documentation**: Builds one master HTML file across all project sessions
- **Session Linking**: Automatically connects related sessions with smart file detection
- **Project Continuity**: Maintains context and progress tracking across session boundaries
- **Context Management**: AI reminds you when to trigger Chronicle before context limits

### **Professional Output**
- **Interactive HTML Reports**: Rich, searchable documentation with timeline visualization
- **Dual Theme Support**: Light and dark themes with custom color schemes
- **Smart Filtering**: Filter by Design, System, Problem Solving categories
- **Responsive Design**: Works on desktop, tablet, and mobile devices

### **Intelligent Analysis**
- **Workspace Scanning**: Analyzes all project files and their evolution
- **Progress Tracking**: Cumulative metrics, milestones, and velocity analysis
- **Problem-Solution Mapping**: Documents challenges and their resolutions
- **Decision Documentation**: Captures rationale behind key decisions

## 🚀 **Quick Start**

### **Installation**
1. Download `chronicle.kiro.hook` from this repository
2. Copy to your Kiro workspace `.kiro/` folder (create folder if it doesn't exist)
3. Restart Kiro or refresh the hooks panel
4. Chronicle will appear in your available hooks

### **Usage**
1. **Work on your project** across one or multiple sessions
2. **When context gets full**, Kiro will remind you to trigger Chronicle
3. **Manually trigger** the Chronicle hook from the hooks panel
4. **Chronicle generates/updates** your project documentation automatically

## 📊 **Output Files**

Chronicle creates two types of files:

### **Master Documentation**
- `chronicle-[PROJECT-NAME]-master.html` - Cumulative project documentation
- Interactive timeline with all sessions
- Professional styling with filtering and search
- Complete project history and evolution

### **Session Backups**
- `chronicle-[PROJECT-NAME]-session-[N]-[TIMESTAMP].md` - Individual session records
- Markdown format for version control
- Easy sharing and collaboration

## 🎨 **Visual Features**

### **Dual Theme System**
- **Theme 1**: Light, vibrant colors for daytime work
- **Theme 2**: Dark, sophisticated colors for focused sessions

### **Smart Categorization**
- **Design**: UI/UX work, visual elements, user experience (#6B5FD7 / #5549B7)
- **System**: Architecture, infrastructure, technical implementation (#F49355 / #EC7744)
- **Problem Solving**: Debugging, troubleshooting, issue resolution (#F54545 / #ED2323)

### **Interactive Elements**
- Collapsible timeline sections
- Filter buttons for category-based viewing
- Searchable content across all sessions
- Responsive navigation

## 📁 **File Organization**

```
Your-Project/
├── .kiro/
│   └── chronicle.kiro.hook                    # The hook file
├── chronicle-your-project-master.html         # Master documentation
├── chronicle-your-project-session-1-20251231.md
├── chronicle-your-project-session-2-20260101.md
└── [your project files...]
```

## 🔧 **How It Works**

### **Session Detection**
Chronicle automatically detects:
- Existing project documentation in your workspace
- Session continuity based on file naming patterns
- Project evolution through workspace file analysis

### **Cumulative Building**
- **First Session**: Creates new master documentation
- **Subsequent Sessions**: Updates existing documentation with new session data
- **Smart Merging**: Preserves all previous sessions while adding new content

### **Context Management**
Kiro will remind you to trigger Chronicle with:
> 🔔 **Chronicle Reminder**: Our context is getting full. This is a good time to trigger the Chronicle hook to capture this session's progress and update our project documentation.

## 💡 **Use Cases**

### **Software Development**
- Multi-session coding projects
- Feature development across sprints
- Bug fixing and optimization cycles
- Architecture evolution documentation

### **Design Projects**
- UI/UX design iterations
- Design system development
- User research and testing cycles
- Creative exploration processes

### **Learning & Research**
- Complex topic exploration
- Skill development journeys
- Research project documentation
- Knowledge building processes

### **Team Collaboration**
- Handoff documentation
- Decision rationale preservation
- Process optimization tracking
- Knowledge sharing artifacts

## 🎯 **Best Practices**

### **Project Organization**
- Keep all related files in one workspace
- Use consistent project naming
- Trigger Chronicle at natural breakpoints
- Review generated documentation for accuracy

### **Session Management**
- Trigger Chronicle when context approaches limits
- Start new sessions in the same workspace for continuity
- Use descriptive commit messages if using version control
- Archive completed projects to dedicated folders

### **Documentation Quality**
- Review and edit generated reports as needed
- Add manual annotations for important context
- Share reports with team members for feedback
- Use reports for project retrospectives

## 🔄 **Version History**

### **Version 2.0** (Current)
- Multi-session project support
- Cumulative documentation building
- Enhanced workspace analysis
- Context management reminders
- Improved file naming conventions

### **Version 1.0**
- Single-session documentation
- Basic HTML and Markdown output
- Timeline visualization
- Category filtering

## 🤝 **Contributing**

Chronicle is designed to be extensible and customizable:

- **Color Schemes**: Modify theme colors in the hook configuration
- **Categories**: Adjust filter categories for your workflow
- **Templates**: Customize HTML templates for different project types
- **Analysis**: Enhance workspace scanning and analysis logic

## 📞 **Support**

For questions, issues, or feature requests:
- Review the examples in the `/examples` folder
- Check the troubleshooting section below
- Create an issue in this repository
- Share your Chronicle outputs for community learning

## 🔧 **Troubleshooting**

### **Hook Not Appearing**
- Ensure file is in `.kiro/` folder
- Check file permissions
- Restart Kiro completely
- Verify JSON syntax in hook file

### **Documentation Not Updating**
- Check workspace for existing Chronicle files
- Verify project naming consistency
- Ensure sufficient workspace permissions
- Review Kiro's file access settings

### **Styling Issues**
- Clear browser cache if viewing HTML files
- Check for file corruption
- Verify theme switching functionality
- Test in different browsers

---

**Chronicle v2.0** - Created December 31, 2025  
*Automated Documentation for the Future of Collaborative Work*